# Орфей — вокальный тренажёр (Android)

Проект Android Studio (Kotlin). Само приложение лежит в `app/src/main/assets/index.html` и работает офлайн внутри WebView; нативная оболочка выдаёт доступ к микрофону, прогресс хранится на устройстве.

## Способ 1. Получить APK без установки программ (GitHub)
1. Создайте бесплатный аккаунт на github.com → **New repository** (любое имя).
2. Загрузите в него все файлы этой папки (**Add file → Upload files**), включая скрытую папку `.github`.
3. Откройте вкладку **Actions** → «Build APK» → дождитесь зелёной галочки (3–6 минут).
4. Внутри запуска, раздел **Artifacts**, скачайте `orfey-apk` — внутри `app-debug.apk`.

## Способ 2. Android Studio
1. Установите Android Studio, откройте эту папку (**Open**), дождитесь синхронизации Gradle.
2. **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
3. Файл: `app/build/outputs/apk/debug/app-debug.apk`.

## Установка APK на телефон
1. Перенесите `app-debug.apk` на телефон (мессенджер, USB, облако).
2. Откройте файл → разрешите «Установку из неизвестных источников» для этого приложения.
3. Запустите «Орфей» и разрешите доступ к микрофону.

## Публикация в Google Play
Создайте свой ключ подписи (Build → Generate Signed Bundle), замените `signingConfig` в `app/build.gradle.kts` и соберите AAB.
