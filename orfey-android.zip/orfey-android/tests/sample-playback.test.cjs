const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const assets = path.join(__dirname, '../app/src/main/assets');
const html = fs.readFileSync(path.join(assets, 'index.html'), 'utf8');
const samples = fs.readFileSync(path.join(assets, 'samples.js'), 'utf8');

test('exercise demo button is addressable for replacement by a published teacher recording', () => {
  assert.match(html, /data-exercise-demo="\$\{scr\.id\}"/);
  assert.match(samples, /preferredSample\(manifest\.samples,exerciseId\)/);
  assert.match(samples, /candidates\.find\(item => item\.sourceType === "teacher"\)/);
  assert.match(samples, /if\(sample\.sourceType==="teacher"\)/);
  assert.match(samples, /bindTeacherSample\(demoButton,audio\)/);
});

test('teacher sample button can stop playback; unmerged branch content is not used', () => {
  assert.match(samples, /button\.textContent = "■ Остановить образец"/);
  assert.match(samples, /if \(teacherAudio === audio && !audio\.paused\) \{ stopTeacherSample\(\); return; \}/);
  assert.match(samples, /raw\.githubusercontent\.com\/\$\{OWNER\}\/\$\{REPO\}\/main\/samples\/manifest\.json/);
});
