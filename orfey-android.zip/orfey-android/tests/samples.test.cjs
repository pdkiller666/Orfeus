const test = require('node:test');
const assert = require('node:assert/strict');
const Samples = require('../app/src/main/assets/samples.js');

const good = {
  id: '12345678-1234-1234-1234-123456789abc', exerciseId: 'fal', title: 'Мягкий фальцет',
  description: 'Плавный переход без нажима', recordedBy: 'Преподаватель',
  path: 'samples/audio/12345678-1234-1234-1234-123456789abc.wav',
  mimeType: 'audio/wav', sha256: 'a'.repeat(64), sizeBytes: 1000, durationMs: 2400, license: 'CC BY 4.0', status: 'approved'
};

test('public sample entries require approved WAV and a content hash', () => {
  assert.equal(Samples.validEntry(good), true);
  assert.equal(Samples.validEntry({...good, status: 'pending'}), false);
  assert.equal(Samples.validEntry({...good, path: '../../token.txt'}), false);
  assert.equal(Samples.validEntry({...good, id: 'bad-id'}), false);
  assert.equal(Samples.validEntry({...good, sha256: 'short'}), false);
  assert.equal(Samples.validEntry({...good, exerciseId: 'unknown'}), false);
});

test('sample manifest rejects unsupported schema and malformed entries', () => {
  assert.equal(Samples.validManifest({schema: 1, samples: []}), true);
  assert.equal(Samples.validManifest({schema: 2, samples: []}), false);
  assert.equal(Samples.validManifest({schema: 1, samples: [good]}), true);
  assert.equal(Samples.validManifest({schema: 1, samples: [{...good, status: 'pending'}]}), false);
});

test('audio paths resolve only under the public repository sample tree', () => {
  assert.equal(Samples.rootPath('samples/audio/x.wav'), 'https://raw.githubusercontent.com/pdkiller666/Orfeus/main/samples/audio/x.wav');
  assert.equal(Samples.rootPath('samples/audio/a b.wav').includes('a%20b.wav'), true);
});
