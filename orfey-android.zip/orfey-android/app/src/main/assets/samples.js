(function (root) {
  "use strict";
  const OWNER = "pdkiller666";
  const REPO = "Orfeus";
  const MANIFEST = `https://raw.githubusercontent.com/${OWNER}/${REPO}/main/samples/manifest.json`;
  const ids = new Set(["range", "one", "step", "fal", "dyn", "pop", "vib", "belt", "tw", "grit", "mel", "sub", "game", "vib2", "fal2", "tw2", "belt2", "mel2", "sub2"]);
  const labels = {range:"Диагностика диапазона",one:"Одна нота",step:"Ступенька «до-ре-до»",fal:"Фальцет",dyn:"Динамика",pop:"Поп-фильтр",vib:"Вибрато",belt:"Белтинг",tw:"Твенг",grit:"Расщепление",mel:"Мелизматика",sub:"Субтон",game:"Попади в ноту",vib2:"Вибрато II",fal2:"Фальцет II",tw2:"Твенг II",belt2:"Белтинг II",mel2:"Мелизматика II",sub2:"Субтон II"};
  let modal = null;
  let session = null;
  let sampleAudioUrl = null;
  let catalogRequestId = 0;
  let timer = null;
  const $ = (sel, parent = document) => parent.querySelector(sel);
  const esc = value => String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]));

  function validEntry(item) {
    return !!item && typeof item.id === "string" && /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/.test(item.id) &&
      item.status === "approved" && ["teacher","synthetic"].includes(item.sourceType) && ids.has(item.exerciseId) &&
      typeof item.title === "string" && item.title.length >= 3 && item.title.length <= 80 &&
      typeof item.description === "string" && item.description.length <= 500 &&
      typeof item.recordedBy === "string" && item.recordedBy.length >= 2 && item.recordedBy.length <= 60 &&
      item.path === `samples/audio/${item.id}.wav` &&
      typeof item.sha256 === "string" && /^[a-f0-9]{64}$/.test(item.sha256) &&
      Number.isInteger(item.sizeBytes) && item.sizeBytes >= 44 && item.sizeBytes <= 5 * 1024 * 1024 &&
      item.mimeType === "audio/wav" && Number.isFinite(item.durationMs) && item.durationMs >= 500 && item.durationMs <= 30000 && item.license === "CC BY 4.0";
  }
  function validManifest(data) {
    return !!data && data.schema === 1 && Array.isArray(data.samples) && data.samples.length <= 100 && data.samples.every(validEntry);
  }
  function rootPath(path) { return `https://raw.githubusercontent.com/${OWNER}/${REPO}/main/${path.split("/").map(encodeURIComponent).join("/")}`; }

  function openModal(exerciseId, html) {
    closeModal(false);
    modal = document.createElement("section");
    modal.className = "sample-modal";
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    modal.setAttribute("aria-label", "Загрузка аудиообразца");
    modal.innerHTML = `<div class="sample-sheet"><button class="sample-close" type="button" aria-label="Закрыть">×</button>${html}</div>`;
    document.body.appendChild(modal);
    modal.dataset.exerciseId = exerciseId;
    $(".sample-close", modal).addEventListener("click", () => closeModal(true));
    modal.addEventListener("keydown", event => { if (event.key === "Escape") closeModal(true); });
    return modal;
  }
  function closeModal(cleanup = true) {
    if (cleanup && session) {
      if (session.pendingMicRequest) session.pendingMicRequest.cancelled = true;
      try { if (session.recorder && session.recorder.state !== "inactive") session.recorder.stop(); } catch (_) {}
      if (session.stream) session.stream.getTracks().forEach(track => track.stop());
      if (session.objectUrl) URL.revokeObjectURL(session.objectUrl);
      if (session.previewUrl) URL.revokeObjectURL(session.previewUrl);
      session = null;
    }
    if (timer) { clearTimeout(timer); timer = null; }
    if (modal) modal.remove();
    modal = null;
  }

  function renderTokenGate(exerciseId, message = "") {
    openModal(exerciseId, `<p class="mu sm">Упражнение</p><h1>Доступ преподавателя</h1><p class="mu">Для отправки записи напрямую в GitHub подключите токен с ограниченным доступом только к репозиторию Orfeus. Четырёхзначный код не выдаёт право записи.</p>
      <div class="sample-warning"><b>Нужен fine-grained token</b><br>Repository access: только <code>pdkiller666/Orfeus</code>.<br>Permissions: <b>Contents — Read and write</b>; <b>Pull requests — Read and write</b>. Срок действия задайте минимальный. У аккаунта также должно быть право Write в репозитории.</div>
      <p><a class="sample-external" href="https://github.com/settings/personal-access-tokens/new" target="_blank" rel="noopener">Создать fine-grained token на GitHub</a></p>
      <label class="sample-field">GitHub token<input id="sampleToken" type="password" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="github_pat_…"></label>
      <p id="sampleAuthStatus" class="mu sm" role="status">${esc(message)}</p>
      <button id="sampleConnect" class="btn" type="button">Проверить и сохранить на устройстве</button>
      <p class="mu sm">Токен хранится зашифрованным Android Keystore на этом устройстве и не отправляется никуда кроме api.github.com. Его можно удалить в этом окне.</p>`);
    $("#sampleConnect", modal).addEventListener("click", () => {
      const input = $("#sampleToken", modal);
      const value = input.value.trim(); input.value = "";
      if (!value) { $("#sampleAuthStatus", modal).textContent = "Вставьте fine-grained token."; return; }
      $("#sampleAuthStatus", modal).textContent = "Проверяю токен и доступ к репозиторию…";
      $("#sampleConnect", modal).disabled = true;
      if (!root.OrfeyGitHub) { $("#sampleAuthStatus", modal).textContent = "Эта версия приложения не поддерживает GitHub-загрузку."; return; }
      root.OrfeyGitHub.saveToken(value);
    });
  }

  function renderEditor(exerciseId, login = "") {
    const label = labels[exerciseId] || exerciseId;
    session = {exerciseId, recorder:null, stream:null, chunks:[], blob:null, objectUrl:null, previewUrl:null, duration:0, start:0, end:0, busy:false};
    openModal(exerciseId, `<p class="mu sm">Образец для упражнения</p><h1>${esc(label)}</h1>
      <p class="mu">Запишите короткую демонстрацию на 30 секунд максимум. После остановки можно выбрать фрагмент, прослушать его и при необходимости перезаписать.</p>
      <div class="sample-warning"><b>Важно: отправка делает аудио публичным немедленно.</b> Репозиторий открыт, поэтому WAV станет доступен любому пользователю GitHub сразу после отправки в ветку — ещё до проверки или слияния Pull Request. Удаление файла не гарантирует удаления скопированных копий. Отправляйте только запись, которую вы готовы опубликовать открыто.</div>
      ${["belt","belt2","tw","tw2","grit"].includes(exerciseId) ? `<div class="sample-warning"><b>Нужна педагогическая проверка.</b> Pull Request нужен для включения образца в каталог приложения; он не скрывает уже отправленный публичный файл. Не используйте запись как инструкцию форсировать голос.</div>` : ""}
      <div class="sample-rec-controls"><button id="sampleRecord" class="btn" type="button">● Начать запись</button><button id="sampleStop" class="btn s" type="button" disabled>■ Остановить</button></div>
      <p id="sampleRecordStatus" class="mu sm" role="status">Микрофон включится только после нажатия «Начать запись».</p>
      <audio id="sampleAudio" controls preload="none" hidden></audio>
      <div id="sampleTrim" hidden><h2>Выберите фрагмент</h2><label class="sample-field">Начало · <span id="sampleStartLabel">0,00</span> с<input id="sampleStart" type="range" min="0" max="1" step="0.01" value="0"></label><label class="sample-field">Конец · <span id="sampleEndLabel">0,00</span> с<input id="sampleEnd" type="range" min="0" max="1" step="0.01" value="1"></label><p id="sampleTrimStatus" class="mu sm">Длительность: —</p><button id="samplePreviewTrim" class="btn s" type="button">▶ Прослушать выбранный фрагмент</button><button id="sampleRedo" class="sample-link" type="button">Записать заново</button></div>
      <label class="sample-field">Название образца<input id="sampleTitle" maxlength="80" placeholder="Например: мягкий переход в головной регистр"></label>
      <label class="sample-field">Короткое описание<textarea id="sampleDescription" maxlength="500" rows="3" placeholder="Что именно демонстрирует образец"></textarea></label>
      <label class="sample-field">Автор / преподаватель<input id="sampleRecordedBy" maxlength="60" value="${esc(login)}" placeholder="Имя для публичной атрибуции"></label>
      <label class="sample-consent"><input id="sampleConsent" type="checkbox"><span>Я подтверждаю право на публикацию и согласие исполнителя. Я понимаю, что аудио и указанные авторские сведения станут общедоступными немедленно после отправки в публичную ветку GitHub — до проверки и слияния PR — и разрешаю распространение записи по <a class="sample-external" href="https://creativecommons.org/licenses/by/4.0/" target="_blank" rel="noopener">CC BY 4.0</a>.</span></label>
      <p class="mu sm">Отправка создаст публичную ветку и Pull Request. WAV доступен сразу после отправки; проверка нужна только для включения записи в каталог приложения.</p>
      <p id="sampleUploadStatus" class="mu sm" role="status"></p>
      <button id="sampleSubmit" class="btn" type="button" disabled>Отправить на проверку в GitHub</button>
      <button id="sampleDisconnect" class="sample-link" type="button">Отключить GitHub на этом устройстве</button>`);
    const rec = $("#sampleRecord", modal), stop = $("#sampleStop", modal), status = $("#sampleRecordStatus", modal);
    rec.addEventListener("click", startRecording);
    stop.addEventListener("click", stopRecording);
    $("#sampleRedo", modal).addEventListener("click", () => { resetTake(); status.textContent = "Готово к новой записи."; });
    $("#sampleStart", modal).addEventListener("input", updateTrim);
    $("#sampleEnd", modal).addEventListener("input", updateTrim);
    $("#samplePreviewTrim", modal).addEventListener("click", previewTrim);
    $("#sampleDisconnect", modal).addEventListener("click", () => { root.OrfeyGitHub.forgetToken(); closeModal(true); });
    $("#sampleSubmit", modal).addEventListener("click", submitSample);
  }

  async function startRecording() {
    const take = session, activeModal = modal;
    if (!take || take.recorder || take.pendingMicRequest) return;
    const pending = {cancelled:false}; take.pendingMicRequest = pending;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:false,noiseSuppression:false,autoGainControl:false}});
      if (session !== take || modal !== activeModal || pending.cancelled) {
        stream.getTracks().forEach(track => track.stop());
        return;
      }
      take.pendingMicRequest = null;
      take.stream = stream;
      const mime = MediaRecorder.isTypeSupported("audio/webm;codecs=opus") ? "audio/webm;codecs=opus" : "audio/webm";
      take.recorder = new MediaRecorder(stream, {mimeType:mime, audioBitsPerSecond:96000});
      take.chunks = [];
      take.recorder.ondataavailable = event => { if (event.data && event.data.size && session === take) take.chunks.push(event.data); };
      take.recorder.onstop = () => {
        if (session !== take || modal !== activeModal) return;
        if (take.stream) take.stream.getTracks().forEach(track => track.stop());
        take.stream = null;
        take.blob = new Blob(take.chunks, {type:take.recorder.mimeType || "audio/webm"});
        take.recorder = null;
        if (take.blob.size > 5 * 1024 * 1024) { $("#sampleRecordStatus", activeModal).textContent = "Запись больше 5 МБ. Запишите короче."; return; }
        take.objectUrl = URL.createObjectURL(take.blob);
        const audio = $("#sampleAudio", activeModal); audio.src = take.objectUrl; audio.hidden = false;
        decodeTake(take.blob).then(decoded => {
          if (session !== take || modal !== activeModal) return;
          take.duration = decoded.duration; take.start = 0; take.end = decoded.duration;
          $("#sampleTrim", activeModal).hidden = false;
          for (const id of ["sampleStart","sampleEnd"]) { const slider = $("#" + id, activeModal); slider.max = decoded.duration.toFixed(2); }
          $("#sampleEnd", activeModal).value = decoded.duration.toFixed(2);
          $("#sampleRecordStatus", activeModal).textContent = `Запись готова · ${decoded.duration.toFixed(1)} с. Прослушайте и выберите границы.`;
          updateTrim();
        }).catch(() => { if(session===take&&modal===activeModal)$("#sampleRecordStatus", activeModal).textContent = "Не удалось обработать эту запись. Попробуйте другой браузер или запишите короче."; });
      };
      take.recorder.start(250);
      $("#sampleRecord", activeModal).disabled = true; $("#sampleStop", activeModal).disabled = false;
      $("#sampleRecordStatus", activeModal).textContent = "Идёт запись… максимум 30 секунд.";
      timer = setTimeout(() => { if(session===take)stopRecording(); }, 30000);
    } catch (error) {
      if (session === take && modal === activeModal) {
        take.pendingMicRequest = null;
        $("#sampleRecordStatus", activeModal).textContent = "Не удалось подключить микрофон. Откройте настройки доступа и повторите запись.";
          if (window.orfeyShowMicPermissionHelp) window.orfeyShowMicPermissionHelp(error);
      }
    }
  }
  function stopRecording() {
    if (timer) { clearTimeout(timer); timer = null; }
    if (!session || !session.recorder) return;
    if (session.recorder.state !== "inactive") session.recorder.stop();
    $("#sampleRecord", modal).disabled = false; $("#sampleStop", modal).disabled = true;
    if (session.stream) session.stream.getTracks().forEach(track => track.stop());
    $("#sampleRecordStatus", modal).textContent = "Обрабатываю запись…";
  }
  function resetTake() {
    if (!session) return;
    if (session.objectUrl) URL.revokeObjectURL(session.objectUrl);
    if (session.previewUrl) URL.revokeObjectURL(session.previewUrl);
    session.blob = null; session.objectUrl = null; session.previewUrl = null; session.duration = 0; session.start = 0; session.end = 0;
    $("#sampleAudio", modal).hidden = true; $("#sampleAudio", modal).removeAttribute("src"); $("#sampleTrim", modal).hidden = true; $("#sampleSubmit", modal).disabled = true;
  }
  function updateTrim() {
    if (!session || !session.duration) return;
    let start = Number($("#sampleStart", modal).value), end = Number($("#sampleEnd", modal).value);
    if (start > end - 0.25) { if (document.activeElement === $("#sampleStart", modal)) start = Math.max(0, end - 0.25); else end = Math.min(session.duration, start + 0.25); }
    session.start = start; session.end = end;
    $("#sampleStart", modal).value = start; $("#sampleEnd", modal).value = end;
    $("#sampleStartLabel", modal).textContent = start.toFixed(2).replace(".", ",");
    $("#sampleEndLabel", modal).textContent = end.toFixed(2).replace(".", ",");
    const duration = end - start;
    $("#sampleTrimStatus", modal).textContent = `Выбранный фрагмент: ${duration.toFixed(2).replace(".", ",")} с`;
    $("#sampleSubmit", modal).disabled = duration < 0.5 || duration > 30;
  }
  async function decodeTake(blob = session && session.blob) {
    const context = new AudioContext();
    try { return await context.decodeAudioData(await blob.arrayBuffer()); }
    finally { context.close(); }
  }
  function encodeWav(buffer, start, end) {
    const inputRate = buffer.sampleRate, rate = Math.min(44100, inputRate);
    const first = Math.max(0, Math.floor(start * inputRate));
    const count = Math.max(0, Math.floor((end - start) * rate));
    const bytes = new ArrayBuffer(44 + count * 2), view = new DataView(bytes);
    const ascii = (offset, text) => { for (let i = 0; i < text.length; i++) view.setUint8(offset + i, text.charCodeAt(i)); };
    ascii(0,"RIFF"); view.setUint32(4,36+count*2,true); ascii(8,"WAVE"); ascii(12,"fmt "); view.setUint32(16,16,true); view.setUint16(20,1,true); view.setUint16(22,1,true); view.setUint32(24,rate,true); view.setUint32(28,rate*2,true); view.setUint16(32,2,true); view.setUint16(34,16,true); ascii(36,"data"); view.setUint32(40,count*2,true);
    const channels = Array.from({length:buffer.numberOfChannels},(_,i)=>buffer.getChannelData(i));
    for (let i=0;i<count;i++) {
      const position = first + i * inputRate / rate, index = Math.min(buffer.length - 1, Math.floor(position));
      const fraction = position - index; let sample = 0;
      for (const channel of channels) sample += (channel[index] || 0) * (1 - fraction) + (channel[Math.min(index + 1, buffer.length - 1)] || 0) * fraction;
      sample = Math.max(-1,Math.min(1,sample/channels.length));
      view.setInt16(44+i*2,sample<0?sample*0x8000:sample*0x7fff,true);
    }
    return new Blob([bytes],{type:"audio/wav"});
  }
  async function makeEditedWav(take = session) { if (!take || !take.blob) throw new Error("Сначала запишите образец."); const decoded=await decodeTake(take.blob); return encodeWav(decoded,take.start,take.end); }
  async function previewTrim() {
    const take=session, activeModal=modal;
    try {
      const blob=await makeEditedWav(take);
      if(session!==take||modal!==activeModal)return;
      if(take.previewUrl)URL.revokeObjectURL(take.previewUrl);
      take.previewUrl=URL.createObjectURL(blob);
      const audio=$("#sampleAudio",activeModal);audio.src=take.previewUrl;audio.hidden=false;await audio.play();
    } catch (_) { if(session===take&&modal===activeModal)$("#sampleRecordStatus",activeModal).textContent="Не удалось подготовить фрагмент для прослушивания."; }
  }
  async function submitSample() {
    const button=$("#sampleSubmit",modal), status=$("#sampleUploadStatus",modal);
    const title=$("#sampleTitle",modal).value.trim(),description=$("#sampleDescription",modal).value.trim(),recordedBy=$("#sampleRecordedBy",modal).value.trim();
    if(title.length<3||recordedBy.length<2){status.textContent="Заполните название и имя преподавателя.";return;}
    if(!$("#sampleConsent",modal).checked){status.textContent="Подтвердите публичную публикацию до проверки PR, права и согласие исполнителя.";return;}
    if(!window.confirm("Последнее предупреждение: после отправки аудиозапись будет публично доступна в GitHub немедленно, даже если Pull Request ещё не проверен или не будет принят. Продолжить?"))return;
    button.disabled=true;status.textContent="Подготавливаю и отправляю WAV в публичную ветку GitHub…";
    try {
      const take=session;
      const blob=await makeEditedWav(take); if(session!==take||!modal)return; if(blob.size>5*1024*1024)throw new Error("WAV превышает 5 МБ. Уменьшите длительность фрагмента.");
      const base64=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result).split(",")[1]);reader.onerror=reject;reader.readAsDataURL(blob);});
      const payload={id:crypto.randomUUID?crypto.randomUUID():`${Date.now()}-sample-${Math.random().toString(16).slice(2)}`,exerciseId:session.exerciseId,title,description,recordedBy,durationMs:Math.round((take.end-take.start)*1000),consent:true,wavBase64:base64};
      if(session!==take||!modal)return;
      root.OrfeyGitHub.submitSample(JSON.stringify(payload));
    } catch (error) { if(modal&&button.isConnected){button.disabled=false;status.textContent=error.message||"Не удалось подготовить аудио.";} }
  }

  root.onGitHubTokenResult = (ok, login, message) => {
    if (!modal) return;
    if (ok) renderEditor(modal.dataset.exerciseId,login);
    else {
      const status=$("#sampleAuthStatus",modal); if(status) status.textContent=message;
      const button=$("#sampleConnect",modal); if(button) button.disabled=false;
    }
  };
  root.onSampleUploadResult = (ok, url, message) => {
    if (!modal) return;
    const status=$("#sampleUploadStatus",modal), button=$("#sampleSubmit",modal);
    if(status) status.textContent=message;
    if(button) button.disabled=false;
    if(ok && url && /^https:\/\/github\.com\/pdkiller666\/Orfeus\/pull\/\d+/.test(url)) {
      const link=document.createElement("a"); link.href=url; link.target="_blank"; link.rel="noopener"; link.className="sample-external"; link.textContent="Открыть Pull Request"; status?.after(link);
      if(button) button.textContent="Отправлено на проверку";
    }
  };

  function openUploader(exerciseId) {
    if (!ids.has(exerciseId)) return;
    if (typeof root.stopPreview === "function") root.stopPreview();
    document.querySelectorAll("#publishedSample audio").forEach(audio => audio.pause());
    if (!root.OrfeyGitHub) { renderTokenGate(exerciseId,"Для загрузки установите актуальную версию приложения."); return; }
    if (root.OrfeyGitHub.hasToken()) renderEditor(exerciseId);
    else renderTokenGate(exerciseId);
  }
  root.openSampleUploader = openUploader;
  root.loadExerciseSample = async exerciseId => {
    const mount=$("#publishedSample"); if(!mount||!ids.has(exerciseId))return;
    const requestId=++catalogRequestId;
    if(sampleAudioUrl){URL.revokeObjectURL(sampleAudioUrl);sampleAudioUrl=null;}
    mount.replaceChildren();
    let manifest;
    try {
      const response=await fetch(`${MANIFEST}?v=${Date.now()}`,{cache:"no-store",headers:{"Cache-Control":"no-cache"}});
      if(!response.ok)throw new Error("network");
      manifest=await response.json(); if(!validManifest(manifest))throw new Error("manifest");
      try{localStorage.setItem("orfey_sample_manifest_v1",JSON.stringify(manifest));}catch(_){}
    } catch (_) {
      try { const saved=JSON.parse(localStorage.getItem("orfey_sample_manifest_v1")||"null"); if(validManifest(saved))manifest=saved; } catch(__){}
    }
    if(!manifest||requestId!==catalogRequestId||!mount.isConnected)return;
    const candidates=manifest.samples.filter(item=>item.exerciseId===exerciseId&&validEntry(item)).sort((a,b)=>String(b.createdAt||"").localeCompare(String(a.createdAt||"")));
    if(!candidates.length)return;
    const sample=candidates[0];
    const synthetic=sample.sourceType==="synthetic";
    const card=document.createElement("div");card.className="sample-public card";
    const heading=document.createElement("b");heading.textContent=synthetic?"Синтетический тестовый ориентир":"Образец преподавателя";card.appendChild(heading);
    if(synthetic){const notice=document.createElement("p");notice.className="mu sm";notice.textContent="Синтезированный сигнал для проверки плеера и точности высоты тона; это не голос певца и не педагогическая рекомендация.";card.appendChild(notice);}
    const title=document.createElement("p");title.textContent=sample.title;card.appendChild(title);
    if(sample.description){const description=document.createElement("p");description.className="mu sm";description.textContent=sample.description;card.appendChild(description);}
    const meta=document.createElement("p");meta.className="mu sm";meta.textContent=`${sample.recordedBy||"Преподаватель"} · лицензия ${sample.license}`;card.appendChild(meta);
    const status=document.createElement("p");status.className="mu sm";status.textContent="Загружаю и проверяю образец…";card.appendChild(status);mount.appendChild(card);
    try {
      const blob=await getCachedAudio(sample.sha256)||await downloadAndVerify(sample);
      if(requestId!==catalogRequestId||!mount.isConnected)return;
      await cacheAudio(sample.sha256,blob);
      const audio=document.createElement("audio");audio.controls=true;audio.preload="none";sampleAudioUrl=URL.createObjectURL(blob);audio.src=sampleAudioUrl;card.insertBefore(audio,status);status.remove();
    } catch (_) { status.textContent="Не удалось загрузить образец. Проверьте интернет и нажмите «Обновить»."; }
  };
  root.refreshExerciseSample = id => root.loadExerciseSample(id);
  root.orfeySamplesPause = () => {
    if (!session) return;
    if (session.pendingMicRequest) session.pendingMicRequest.cancelled = true;
    if (session.recorder) stopRecording();
    else if (session.stream) { session.stream.getTracks().forEach(track=>track.stop()); session.stream=null; }
  };

  async function downloadAndVerify(sample) {
    const response=await fetch(rootPath(sample.path),{cache:"no-store"}); if(!response.ok)throw new Error("download");
    const bytes=await response.arrayBuffer(); if(bytes.byteLength!==sample.sizeBytes)throw new Error("size");
    const digest=Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256",bytes))).map(x=>x.toString(16).padStart(2,"0")).join("");
    if(digest!==sample.sha256)throw new Error("hash"); return new Blob([bytes],{type:"audio/wav"});
  }
  function openDb() {
    return new Promise((resolve,reject)=>{const request=indexedDB.open("orfey_samples_cache",1);request.onupgradeneeded=()=>request.result.createObjectStore("audio");request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);});
  }
  async function getCachedAudio(hash) {
    try { const db=await openDb(); return await new Promise((resolve,reject)=>{const request=db.transaction("audio","readonly").objectStore("audio").get(hash);request.onsuccess=()=>resolve(request.result||null);request.onerror=()=>reject(request.error);}); }
    catch (_) { return null; }
  }
  async function cacheAudio(hash, blob) {
    try { const db=await openDb(); await new Promise((resolve,reject)=>{const tx=db.transaction("audio","readwrite");tx.objectStore("audio").put(blob,hash);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);}); }
    catch (_) { /* Offline cache is a best-effort enhancement. */ }
  }

  if (typeof module === "object" && module.exports) module.exports={validEntry,validManifest,rootPath};
})(typeof window !== "undefined" ? window : globalThis);
