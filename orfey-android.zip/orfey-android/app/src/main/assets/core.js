(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.OrfeyCore = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  const finite = (value, fallback = 0) =>
    typeof value === "number" && Number.isFinite(value) ? value : fallback;
  const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
  const isRecord = value => value !== null && typeof value === "object" && !Array.isArray(value);
  const uniqueStrings = value => Array.isArray(value)
    ? [...new Set(value.filter(item => typeof item === "string").slice(-500))]
    : [];

  function yinPitch(buffer, sampleRate, minHz = 50, maxHz = 1000) {
    if (!buffer || buffer.length < 128 || !Number.isFinite(sampleRate) || sampleRate < 8000) return -1;
    const length = Math.floor(buffer.length / 2);
    const signal = new Float32Array(length);
    let mean = 0;
    for (let i = 0; i < length; i++) {
      signal[i] = buffer[i * 2];
      mean += signal[i];
    }
    mean /= length;
    let energy = 0;
    for (let i = 0; i < length; i++) {
      signal[i] -= mean;
      energy += signal[i] * signal[i];
    }
    if (energy / length < 1e-6) return -1;

    const rate = sampleRate / 2;
    const minTau = Math.max(2, Math.floor(rate / maxHz));
    const maxTau = Math.min(Math.floor(rate / minHz), length - 2);
    if (maxTau <= minTau) return -1;
    const normalized = new Float64Array(maxTau + 1);
    let cumulative = 0;
    for (let tau = 1; tau <= maxTau; tau++) {
      let sum = 0;
      const limit = length - maxTau;
      for (let i = 0; i < limit; i++) {
        const delta = signal[i] - signal[i + tau];
        sum += delta * delta;
      }
      cumulative += sum;
      normalized[tau] = cumulative > 0 ? (sum * tau) / cumulative : 1;
    }

    const threshold = 0.16;
    let selected = -1;
    for (let tau = minTau; tau <= maxTau; tau++) {
      if (normalized[tau] < threshold) {
        while (tau + 1 <= maxTau && normalized[tau + 1] < normalized[tau]) tau++;
        selected = tau;
        break;
      }
    }
    if (selected < 0) {
      let best = 1;
      for (let tau = minTau; tau <= maxTau; tau++) {
        if (normalized[tau] < best) {
          best = normalized[tau];
          selected = tau;
        }
      }
      if (selected < 0 || best > 0.3) return -1;
    }

    const left = Math.max(minTau, selected - 1);
    const right = Math.min(maxTau, selected + 1);
    const a = normalized[left];
    const b = normalized[selected];
    const c = normalized[right];
    const denominator = a - 2 * b + c;
    const adjustment = denominator === 0 ? 0 : 0.5 * (a - c) / denominator;
    const period = selected + Math.max(-0.5, Math.min(0.5, adjustment));
    const frequency = rate / period;
    return frequency >= minHz && frequency <= maxHz ? frequency : -1;
  }

  function pitchCue(cents) {
    const value = finite(cents, 0);
    if (Math.abs(value) <= 30) return "В зоне";
    return value > 0 ? "чуть выше" : "чуть ниже";
  }

  function localDateKey(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  }

  function computeGain(score, previousBest, hasPreviousBest) {
    const current = clamp(Math.round(finite(score, 0)), 0, 100);
    if (!hasPreviousBest) return Math.round(current / 2) + 10;
    const previous = clamp(Math.round(finite(previousBest, 0)), 0, 100);
    return current > previous ? Math.round((current - previous) / 2) + 2 : 0;
  }

  function normalizeState(raw, defaults, maxHistory = 500) {
    const base = isRecord(defaults) ? defaults : {};
    const input = isRecord(raw) ? raw : {};
    const state = { ...base, ...input };

    state.streak = clamp(Math.floor(finite(state.streak, 0)), 0, 1000000);
    state.pts = clamp(Math.floor(finite(state.pts, 0)), 0, 1000000000);
    state.freeze = clamp(Math.floor(finite(state.freeze, 0)), 0, 2);
    state.best = isRecord(state.best)
      ? Object.fromEntries(Object.entries(state.best)
          .filter(([, value]) => Number.isFinite(value))
          .map(([key, value]) => [key, clamp(value, 0, 100)]))
      : {};
    state.hist = Array.isArray(state.hist)
      ? state.hist.filter(item => isRecord(item)
          && typeof item.d === "string"
          && typeof item.id === "string"
          && Number.isFinite(item.s))
        .slice(-maxHistory)
        .map(item => ({
          d: item.d,
          id: item.id,
          s: clamp(item.s, 0, 100),
          g: clamp(finite(item.g, 0), 0, 1000000)
        }))
      : [];
    state.badges = uniqueStrings(state.badges);
    state.dn = uniqueStrings(state.dn);
    state.range = Array.isArray(state.range)
      && state.range.length === 2
      && state.range.every(Number.isFinite)
      && state.range[0] < state.range[1]
      ? state.range.map(value => clamp(value, 0, 127))
      : (base.range ?? null);
    state.seen = state.seen === true || state.seen === 1 ? 1 : 0;
    state.theme = ["", "dark", "light"].includes(state.theme) ? state.theme : "";
    state.record = state.record === true;
    state.quizRewarded = state.quizRewarded === true;
    state.blindRewarded = state.blindRewarded === true;
    state.last = typeof state.last === "string" && /^\d{4}-\d{2}-\d{2}$/.test(state.last)
      ? state.last : "";
    state.rem = typeof state.rem === "string" && /^\d{2}:\d{2}$/.test(state.rem)
      ? state.rem : "";
    return state;
  }

  return { yinPitch, pitchCue, localDateKey, computeGain, normalizeState };
});
